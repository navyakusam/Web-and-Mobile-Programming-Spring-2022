import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../environments/environment';

@Component({
  selector: 'app-recipes',
  templateUrl: './search-recipe.component.html',
  styleUrls: ['./search-recipe.component.css'],
})
export class SearchRecipeComponent implements OnInit {
  public itemName: string;
  public recipesList = [];
  public restaurants = [];
  public cityName = '';
  private APP_ID = environment.APP_ID;
  private APP_KEY = environment.APP_KEY;
  private food_url = `https://api.edamam.com/search?app_id=${this.APP_ID}&app_key=${this.APP_KEY}`;

  private CLIENT_ID = environment.CLIENT_ID;
  private CLIENT_SECRET = environment.CLIENT_SECRET_KEY;
  private place_url = `https://api.foursquare.com/v2/venues/search?
      client_id=${this.CLIENT_ID}&client_secret=${this.CLIENT_SECRET}&v=20220220`;


  constructor(private http: HttpClient) {}

  ngOnInit() {}

  getRecipeDetails() {
    this.restaurants = [];
    // this.http.get(this.food_url + `&q=${this.itemName}`).subscribe((data) => {
    this.http.get(`https://api.edamam.com/search?app_id=6221fb92&app_key=3438676d078523e66cefff39bd724545&q=chicken`).subscribe((data) => {
      const recipes = data['hits'];
      console.log(recipes);
      recipes.map(recipe => {
        console.log(recipe);
        const recipeObj = {
          name : recipe['recipe']['label'],
          url : recipe['recipe']['url'],
          icon : recipe['recipe']['image'],
          ingredients: recipe['recipe']['ingredientLines'].slice(0, 4)
        };
        this.recipesList.push(recipeObj);
      });
    });
    let headers = {
      'Accept': 'application/json',
      'Authorization': 'APIKEY'
    }

    // this.http.get(this.place_url + `&near=${this.cityName}&query=${this.itemName}`)
    this.http.get(`https://api.foursquare.com/v2/venues/explore?client_id=BSHESXDDOXAOWKDCRT1OWQU430SJXYYWB2MM2BAZKTW2KR45&client_secret=E1CBBNN3IE3FNOCC51UU53PC2IP0R4RFOSUFR10BJOVHDT4M&v=20220220&query=chicken&near=Kansas`)
        .subscribe((data) => {
        const response = data['response'];
        const items = response['groups'][0]['items'].slice(0, 5);
        items.map((item) => {
          const venueObj = {
            id: item['venue']['id'],
            name: item['venue']['name'],
            address: {
              street: item['venue']['location']['address'],
              city: item['venue']['location']['city'],
              state: item['venue']['location']['state'],
              postalCode: item['venue']['location']['postalCode'],
              country: item['venue']['location']['country'],
            },
            category: item['venue']['categories'][0]['name'],
          };
          this.restaurants.push(venueObj);

          console.log(item);
        });
      });
  }
}
